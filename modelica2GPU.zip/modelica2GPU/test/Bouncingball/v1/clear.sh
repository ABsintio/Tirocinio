rm *.o
rm *.c
rm *.mat
rm *.h
rm *.json
rm v1.BouncingBall_init.xml
rm v1.BouncingBall
rm *.csv
rm *.makefile
rm *.log
rm *.libs

