rm *.o
rm *.c
rm *.mat
rm *.h
rm *.json
rm v2.BouncingBall_init.xml
rm v2.BouncingBall
rm *.makefile
rm *.log
rm *.libs

