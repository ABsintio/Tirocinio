rm *.o
rm *.c
rm *.mat
rm *.h
rm *.json
rm system_init.xml
rm *.csv
rm *.makefile
rm *.log
rm *.libs

